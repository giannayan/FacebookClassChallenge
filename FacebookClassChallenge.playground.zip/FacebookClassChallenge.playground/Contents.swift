//FacebookClassChallenge
class FacebookProfile {
    
    
    //ITERATION 0: Variable properties and constant properties.
    
    //Step 0: Create your attributes section--What is a facebook profile made of?
    /*****YOUR CODE GOES HERE*****/
   
    
    
    //Step 2: Create an object from the class outside of the class (see below).
    
    //Step 3: Print the object.
    //Step 4: Push Iteration 0 to GitHub.
    
    //KARLIE'S FACEBOOK
//    var bio = "6'2 giraffe from the Lou"
//    var userName = "Karlie Kloss"
//    var friendCount = 1797405
//    var friendList = ["Josh"]
//    let birthday = "August 3, 1992"
//    var relationshipStatus = "Married"
    
    var bio : String
    var userName : String
    var friendCount : Int
    var friendList : [String]
    let birthday : String
    var relationshipStatus : String
    
    
    //Step 1: Create pre-selected options for certain attribute(s).
    /*****YOUR CODE GOES HERE*****/
    
    //for relationshipStatus
    let optionOne = "Single"
    let optionTwo = "It's complicated"
    let optionThree = "In a relationship"
    let optionFour = "Engaged"
    let optionFive = "Married"
    let optionSix = "Divorced"
    let optionSeven = "Depressed"
    
//    var karlie = FacebookProfile() //creates object
//    print(karlie) //prints the object __lldb_expr_1.FacebookProfile

    
    //ITERATION 1: Add an initializer so that we can create multiple facebook profiles.
    
    //Step 0: Generate an initializer based on the variable properties and constant properties.
    //Note: You may need to change the properties you created in Iteration 0!
    /*****YOUR CODE GOES HERE*****/
    
    //Step 1: Print your friendCount for your object to see if your initializer works.
    //Step 2: Print your relationshipStatus for your object to see if your initializer works.
    //Step 3: Push Iteration 1 to GitHub.
    
    
    
    
    
    //ITERATION 2: Functions that lets user update properties of their facebook profile -- In other languages, these are sometimes called "Setter" Functions.
    
    //Step 0: Write a function that lets user update their bio
    /*****YOUR CODE GOES HERE*****/
    
    //Step 1: Write a function that lets user update their userName
    /*****YOUR CODE GOES HERE*****/
    
    //Step 2: Write a function that lets user update their friendCount
    /*****YOUR CODE GOES HERE*****/
    
    //Step 3: Write a function that lets user update their birthday
    /*****YOUR CODE GOES HERE*****/
    
    //Step 4: Write a function that lets user update their relationshipStatus
    /*****YOUR CODE GOES HERE*****/
    
    //Step 5: "Set" the properties of the facebook profile using each function.
    //Step 6: Call these functions to make sure that they work.
    //Step 6: Push Iteration 2 to GitHub.
    
    
    
    
    
    //ITERATION 3: Functions that lets the user check their facebook profile informantion -- -- In other languages, these are sometimes called "Getter" Functions.
    
    //Step 0: Write a function that lets user check their bio
    /*****YOUR CODE GOES HERE*****/
    
    //Step 1: Write a function that lets user check their userName
    /*****YOUR CODE GOES HERE*****/
    
    //Step 2-4: Write the rest of the wrapper functions for: friendCount, birthday, relationshipStatus
    /*****YOUR CODE GOES HERE*****/
    
    //Step 5: "Get" the facebook profile information by calling these functions to make sure that they work.
    //Step 6: Push Iteration 3 to GitHub.
    
    
    
    
    


//Test Iterations Here
//Iteration 0 Test

//Iteration 1 Test
    //VERSION IF USER HAS TO INPUT ALL PROFILE INFORMATION
//    init(bioText : String, name: String, followers: Int, relationship: String, following: [String]) {
//        bio = bioText
//        userName = name
//        friendCount = followers
//        relationshipStatus = relationship
//        friendList = following
//
//    }
    
    
init() {
    bio = ""
    userName = ""
    friendCount = 0
    birthday = ""
    relationshipStatus = optionOne
    friendList = ["Me", "Myself", "I"]
 
}
    
//var gianna = FacebookProfile(bioText: "hiiii !", name: "giannayan", followers: 10, relationship: "Single", following: ["Karlie Kloss"])


}//closing bracket for the class

var karlie = FacebookProfile()
print(karlie) //prints the object as __lldb_expr_3.FacebookProfile

//Iteration 1 Test
print(karlie.friendCount) //prints friendCount
print(karlie.relationshipStatus) //prints relationshipStatus


//Iteration 2 Test


//Iteration 3 Test


//Challenge: "Iteration 4" -- Edit your facebook class so Iterations 1, 2, and 3 also include friendList




